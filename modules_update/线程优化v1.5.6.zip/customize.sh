SKIPUNZIP=0
check_magisk_version() {
	ui_print "- Magisk version: $MAGISK_VER_CODE"
	ui_print "- Module version: $(grep_prop version "${TMPDIR}/module.prop")"
	ui_print "- Module versionCode: $(grep_prop versionCode "${TMPDIR}/module.prop")"
	ui_print "********************************************"
	ui_print "- $(grep_prop description "${TMPDIR}/module.prop")"
	if [ "$MAGISK_VER_CODE" -lt 20400 ]; then
		ui_print "********************************************"
		ui_print "! 请安装 Magisk v20.4+ (20400+)"
		abort    "********************************************"
	fi
}
check_required_files() {
	REQUIRED_FILE_LIST="/sys/devices/system/cpu/present /proc/loadavg"
	for REQUIRED_FILE in $REQUIRED_FILE_LIST; do
		if [ ! -e $REQUIRED_FILE ]; then
			ui_print "********************************************"
			ui_print "! $REQUIRED_FILE 文件不存在"
			ui_print "! 请联系模块作者"
			abort    "********************************************"
		fi
	done
}
extract_bin() {
	ui_print "********************************************"
	if [ "$ARCH" == "arm" ]; then
		cp $MODPATH/bin/armeabi-v7a/AppOpt $MODPATH
	elif [ "$ARCH" == "arm64" ]; then
		cp $MODPATH/bin/arm64-v8a/AppOpt $MODPATH
	elif [ "$ARCH" == "x86" ]; then
		cp $MODPATH/bin/x86/AppOpt $MODPATH
	elif [ "$ARCH" == "x64" ]; then
		cp $MODPATH/bin/x86_64/AppOpt -v $MODPATH
	else
		abort "! Unsupported platform: $ARCH"
	fi
	ui_print "- Device platform: $ARCH"
	rm -rf $MODPATH/bin
	[ -f $MODPATH/AppOpt ] && chmod a+x $MODPATH/AppOpt
	if ! $MODPATH/AppOpt -v; then
		abort "! 主程序验证失败，请检查模块zip文件是否损坏"
	fi
}
remove_sys_perf_config() {
	for SYSPERFCONFIG in $(ls /system/vendor/bin/msm_irqbalance); do
		[[ ! -d $MODPATH${SYSPERFCONFIG%/*} ]] && mkdir -p $MODPATH${SYSPERFCONFIG%/*}
		ui_print "- Remove :$SYSPERFCONFIG"
		touch $MODPATH$SYSPERFCONFIG
	done
	if [ -n "$(pm path com.xiaomi.joyose)" ] && [ -n "$(getprop ro.miui.ui.version.code)" ]; then
		pm disable --user 0 com.xiaomi.joyose/.smartop.SmartOpService
		echo 'pm enable com.xiaomi.joyose/.smartop.SmartOpService' >> $MODPATH/uninstall.sh
	fi
}
format_cpu_ranges() {
	echo "$1" | tr ' ' '\n' | sort -n | awk '
	BEGIN { start = -1; last = -1 }
	{
		num = $1
		if (start == -1) {
			start = last = num
		} else if (num == last + 1) {
			last = num
		} else {
			if (start == last) printf "%d,", start
			else printf "%d-%d,", start, last
			start = last = num
		}
	}
	END {
		if (start != -1) {
			if (start == last) printf "%d", start
			else printf "%d-%d", start, last
		}
	}'
}
sorted_groups=$(
	for policy in /sys/devices/system/cpu/cpufreq/policy*; do
		[ -d "$policy" ] || continue
		cpus=$(cat "$policy/related_cpus" 2>/dev/null)
		freq=$(cat "$policy/cpuinfo_max_freq" 2>/dev/null)
		[ -z "$cpus" ] || [ -z "$freq" ] && continue
		echo "$freq:$cpus"
	done | sort -n -t: -k1,1 | awk -F: '
	$1 == prev { cores = cores " " $2; next }
	prev != "" { print prev ":" cores; cores = "" }
	{ prev = $1; cores = $2 }
	END { if (prev != "") print prev ":" cores }'
)

e_core=""; p_core=""; hp_core=""
e_core_freq=0; p_core_freq=0; hp_core_freq=0
total_groups=$(echo "$sorted_groups" | wc -l)
group_index=0
IFS='
'
for line in $sorted_groups; do
	group_index=$((group_index + 1))
	freq="${line%%:*}"
	cpus="${line#*:}"

	if [ $group_index -eq 1 ]; then
		e_core="$cpus"
		e_core_freq="$freq"
	elif [ $group_index -eq $total_groups ]; then
		hp_core="$cpus"
		hp_core_freq="$freq"
	else
		p_core="${p_core:+$p_core }$cpus"
		[ "$freq" -gt "$p_core_freq" ] && p_core_freq="$freq"
	fi
done
unset IFS
[ -n "$e_core" ] && e_core=$(format_cpu_ranges "$e_core")
[ -n "$p_core" ] && p_core=$(format_cpu_ranges "$p_core")
[ -n "$hp_core" ] && hp_core=$(format_cpu_ranges "$hp_core")
all_core="$(cat /sys/devices/system/cpu/present)"
module_instructions() {
	ui_print "********************************************"
	ui_print "线程规则配置文件路径为："
	ui_print "/data/adb/modules/AppOpt/applist.conf"
	ui_print "------------------------------------------"
	ui_print "修改与添加规则无需重启，即时生效"
	ui_print "********************************************"
	cores=$(for cpus in /sys/devices/system/cpu/cpufreq/*/related_cpus; do 
		[ -f "$cpus" ] && cat "$cpus" | wc -w
	done | paste -sd+)
	ui_print "当前$(getprop ro.soc.model)设备为$(nproc)核CPU，规格是：$cores"
	ui_print "可用CPU范围：$all_core"
	ui_print "------------------------------------------"
	[ -n "$e_core" ] && echo "$e_core 为能效小核，频率最高$((e_core_freq/1000)) MHz"
	[ $total_groups -ge 3 ] && [ -n "$p_core" ] && echo "$p_core 为性能中核，频率最高$((p_core_freq/1000)) MHz"
	[ $total_groups -ge 2 ] && [ -n "$hp_core" ] && echo "$hp_core 为高性能大核，频率最高$((hp_core_freq/1000)) MHz"
	ui_print "------------------------------------------"
	ui_print "applist.conf 规则写法示例："
	ui_print "------------------------------------------"
	if [ -n "$all_core" ]; then
		ui_print "允许安卓 '图形显示组件 '调用所有核心："
		ui_print "surfaceflinger=$all_core"
		ui_print "------------------------------------------"
	fi
	if [ -n "$hp_core" ]; then
		ui_print "单独将'图形显示组件'渲染引擎线程绑定到大核："
		ui_print "surfaceflinger{RenderEngine}=$hp_core"
		ui_print "------------------------------------------"
	fi
	if [ -n "$e_core" ]; then
		ui_print "将 '微信' 主进程绑定能效小核："
		ui_print "com.tencent.mm=$e_core"
		ui_print "------------------------------------------"
	fi
	if [ -n "$e_core" ]; then
		ui_print "将 '微信' 消息推送子进程绑定能效小核："
		ui_print "com.tencent.mm:push=$e_core"
		ui_print "------------------------------------------"
	fi
	if [ -n "$hp_core" ]; then
		ui_print "将 '系统界面' 渲染线程绑定到性能大核："
		ui_print "com.android.systemui{RenderThread}=$hp_core"
		ui_print "------------------------------------------"
	fi
	ui_print "更多规则使用说明请参考："
	ui_print "http://AppOpt.suto.top"
	ui_print "********************************************"
}
add_default_rules() {
common_rules="
com.tencent.mm:push=$e_core
com.coolapk.market{RenderThread}=$hp_core
surfaceflinger{RenderEngine}=$hp_core
surfaceflinger=$all_core
com.android.systemui{RenderThread}=$hp_core
"
	if [ -f /data/adb/modules/AppOpt/applist.conf ]; then
		mv $MODPATH/applist.conf $MODPATH/applist.conf.bak
		cp -r /data/adb/modules/AppOpt/applist.conf ${MODPATH}
	else
		for common_rule in $common_rules; do
			if [ -n "${common_rule##*=}" ]; then
				echo $common_rule >> $MODPATH/applist.conf && echo >> $MODPATH/applist.conf
			fi
		done
	fi
}
check_magisk_version
check_required_files
extract_bin
remove_sys_perf_config
module_instructions
add_default_rules
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/*.sh $MODPATH/AppOpt" 0 2000 0755 0755 u:object_r:magisk_file:s0
